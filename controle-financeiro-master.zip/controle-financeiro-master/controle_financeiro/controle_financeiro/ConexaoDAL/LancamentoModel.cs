﻿using System;
using System.Threading.Tasks;

public class LancamentoModel
{
    public int ID { get; set; }
    public string TipoDespesa { get; set; }
    public DateTime DataDespesa { get; set; }
    public string Valor { get; set; }
    public string Descricao { get; set; }
    public string Status { get; set; }
}
