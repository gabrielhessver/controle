﻿using System;
using System.Data;
using Npgsql;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using SQLite;
using Microsoft.Data.Sqlite;
using System.Collections.Generic;
using controle_financeiro.Models;

namespace controle_financeiro
{
    public class DAL
    {
        private static string _servidor = "177.220.159.198"; // ip
        private static string _porta = "5432"; // porta de acesso default
        private static string usuario = "postgres"; // nome do administrador 
        private static string password = "cadastro"; // senha de acesso ao banco de dados
        private static string databaseName = "controle_financeiro"; // nome do banco de dados
        private static string connString = String.Format("Server={0};Port={1};User Id={2};Password={3};Database={4};", _servidor, _porta, usuario, password, databaseName);

        public DAL()
        {
        }
        public static NpgsqlConnection Conn { get; set; }
        public static void Conectar()
        {
            try
            {
                Conn = new NpgsqlConnection(connString);
                Conn.Open();
            }
            catch (Exception ex)
            {
                App.Current.MainPage.DisplayAlert("Erro", "Erro ao conectar" + ex.Message.ToString(), "OK");
                return;
            }
        }

        public static void Desconectar(NpgsqlConnection connection)
        {
            if (connection.State == ConnectionState.Open)
            {
                connection.Close();
            }
        }

        public DataTable SelectLogin(string login, string senha)
        {
            DataTable dtUsuario = new DataTable();
            using (NpgsqlConnection connection = new NpgsqlConnection(connString))
            {
                try
                {
                    Conectar();
                    string SqlQuerry = $"SELECT * FROM public.usuario WHERE nome = '{login}' AND senha = '{senha}'";
                    NpgsqlDataAdapter daUsuario = new NpgsqlDataAdapter(SqlQuerry, connection);
                    DataSet dsUsuario = new DataSet();
                    daUsuario.Fill(dsUsuario);
                    dtUsuario = dsUsuario.Tables[0];
                    return dtUsuario;
                }
                catch (NpgsqlException ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    Desconectar(connection);
                }
            }
            return dtUsuario;
        }
        public static DataTable SelectUsuarios()
        {
            using (NpgsqlConnection connection = new NpgsqlConnection(connString))
            {
                DataSet dsUsuario = new DataSet();
                DataTable dtUsuario = new DataTable();

                try
                {
                    Conectar();
                    string SelectUsuario = "SELECT * FROM public.usuario";
                    NpgsqlDataAdapter daUsuario = new NpgsqlDataAdapter(SelectUsuario, connection);
                    daUsuario.Fill(dsUsuario);
                    dtUsuario = dsUsuario.Tables[0];
                }
                catch (NpgsqlException ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    Desconectar(connection);
                }

                return dtUsuario;
            }
        }

        public void InserirNovoRegistro(int ID, string TipoDespesa, string DataDespesa, string Valor, string Descricao, string Anexo, int IDUsr)
        {
            using (NpgsqlConnection connection = new NpgsqlConnection(connString))
            {
                Conectar();
                int ultPK = 0;
                using (NpgsqlCommand cmdSerial = new NpgsqlCommand("SELECT max(id) from public.carteira;", Conn))
                {
                    NpgsqlDataReader reader = cmdSerial.ExecuteReader();
                    while (reader.Read())
                    {
                        ultPK = Int32.Parse(reader[0].ToString());
                    }
                    Desconectar(connection);
                }

                Conectar();

                    string cmdInsert = string.Format($"INSERT INTO carteira (id, id_usr, tipo_despesa, data_despesa, valor, descricao, anexo) VALUES ({ultPK + 1},'{IDUsr}','{TipoDespesa}','{DataDespesa}', '{Valor}', '{Descricao}', '{Anexo}');");
                    try
                    {
                        NpgsqlCommand cmd = new NpgsqlCommand(cmdInsert, Conn);
                        cmd.ExecuteNonQuery();
                    }
                    catch (NpgsqlException ex)
                    {
                        App.Current.MainPage.DisplayAlert("Erro Conexão", "Erro ao inserir " + ex.Message.ToString() + "\n\r contate o suporte", "OK");
                        return;
                    }
                    catch (Exception ex)
                    {
                        App.Current.MainPage.DisplayAlert("Erro Conexão", "Erro ao inserir " + ex.Message.ToString(), "OK");
                        throw ex;
                    }
                    finally
                    {
                        Desconectar(connection);
                    }
                }
        }


        public async Task<ObservableCollection<LancamentoModel>> SelectCadastro()
        {
            ObservableCollection<LancamentoModel> listaCadastro = new ObservableCollection<LancamentoModel>();

            var aux = await App.SQLiteDbControle.ReadElementos();
            foreach (var ele in aux)
            {
                int infoCarteira = ele.ID;
                Console.WriteLine("imprimir" + infoCarteira);

                using (SqliteConnection connectionProjeto = new SqliteConnection(connString))
                {
                    connectionProjeto.Open();

                    // Ajuste a consulta SQL para buscar os dados do elemento cadastrado
                    string sqlQuery = "SELECT * FROM Elemento WHERE ID = @ID";

                    using (SqliteCommand commProjeto = new SqliteCommand(sqlQuery, connectionProjeto))
                    {
                        commProjeto.Parameters.AddWithValue("@ID", infoCarteira);
                        using (SqliteDataReader readerProjeto = commProjeto.ExecuteReader())
                        {
                            while (readerProjeto.Read())
                            {
                                LancamentoModel lancamento = new LancamentoModel();
                                lancamento.ID = infoCarteira;
                                lancamento.Valor = readerProjeto["Valor"].ToString(); // Ajuste para o nome correto da coluna de valor no banco de dados
                                lancamento.Descricao = readerProjeto["Descricao"].ToString(); // Ajuste para o nome correto da coluna de descrição no banco de dados
                                lancamento.DataDespesa = readerProjeto.GetDateTime(readerProjeto.GetOrdinal("DataDespesa"));
                                // Ajuste para o nome correto da coluna de data no banco de dados
                                lancamento.Status = ""; // Preencha com o status correto do lançamento

                                listaCadastro.Add(lancamento);
                                Console.WriteLine("resultado" + lancamento);
                            }
                        }
                    }

                    connectionProjeto.Close();
                }
            }

            return listaCadastro;
        }
    }
}
