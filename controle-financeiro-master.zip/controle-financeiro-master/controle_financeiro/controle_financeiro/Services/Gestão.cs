﻿using controle_financeiro.Models;
using SQLite;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace controle_financeiro.Services
{
    public class DatabaseService
    {
        private SQLiteAsyncConnection database;

        public DatabaseService(string databasePath)
        {
            // Inicialize a conexão com o banco de dados SQLite
            database = new SQLiteAsyncConnection(databasePath);

            // Crie a tabela se ela não existir
            database.CreateTableAsync<Cadastro>().Wait();
        }

        public Task<int> SalvarItemAsync(Cadastro item)
        {
            return database.InsertAsync(item);
        }

        public Task<int> AtualizarItemAsync(Cadastro item)
        {
            return database.UpdateAsync(item);
        }

        public Task<int> ExcluirItemAsync(Cadastro item)
        {
            return database.DeleteAsync(item);
        }

        public Task<List<Cadastro>> GetItemsAsync()
        {
            return database.Table<Cadastro>().ToListAsync();
        }

        public Task<int> DeleteItemAsync(Cadastro item)
        {
            return database.DeleteAsync(item);
        }
    }
}
