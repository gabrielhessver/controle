﻿using System;
using System.Collections.Generic;
using System.Text;

namespace controle_financeiro.Models
{
    public class Cadastro
    {
        [SQLite.PrimaryKey, SQLite.AutoIncrement]
        public int ID { get; set; }
        public string TipoDespesa { get; set; }
        public string DataDespesa { get; set; }
        public string Valor { get; set; }
        public string Descricao { get; set; }
        public string Anexo { get; set; }
    }

    public class Usuario
    {
        [SQLite.PrimaryKey, SQLite.AutoIncrement]
        public int ID { get; set; }
        public int IDUsuario { get; set; }
        public string Nome { get; set; }
        public string Email { get; set; }
        public string Senha { get; set; }
        public string Matricula { get; set; }
        public string Saldo { get; set; }
        public string Cargo { get; set; }

    }
}
