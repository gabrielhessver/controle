﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using controle_financeiro;
using controle_financeiro.Models;
using Xamarin.Essentials;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace controle_financeiro.View
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Login : ContentPage
    {
        public Models.Usuario _usuario;
        public Login()
        {
            InitializeComponent();
            NavigationPage.SetHasNavigationBar(this, false);
            Button_Entrar.Clicked += Button_Entrar_Clicked;

            this._usuario = new Models.Usuario();
            Task.Run(async () =>
            {
                this._usuario = await App.SQLiteDbUsuario.GetItemAsync(1);

                if (this._usuario != null)
                {
                    EntryUsuario.Text = this._usuario.Nome;
                    EntrySenha.Text = this._usuario.Senha;
                }
            });
        }

        private async void Button_Entrar_Clicked(object sender, EventArgs e)
        {
            try
            {
                DAL Conexao = new DAL();


                if (string.IsNullOrEmpty(EntryUsuario.Text) || string.IsNullOrEmpty(EntrySenha.Text))
                {
                    await DisplayAlert("ERRO!", "Por favor, preencha todos os campos.", "OK");
                    return; // Adicionado o 'return' para sair do método caso os campos não estejam preenchidos
                }

                var usuario = await App.SQLiteDbUsuario.GetItemAsync2(EntryUsuario.Text, EntrySenha.Text);

                // Lógica para validar o login e a senha
                string Usuario_Login = EntryUsuario.Text;
                string Senha_Login = EntrySenha.Text;

                // Exemplo de lógica de validação do login e senha
                if (usuario == null)
                {
                    DataTable resultado = Conexao.SelectLogin(EntryUsuario.Text, EntrySenha.Text);
                    if (resultado != null && resultado.Rows.Count > 0)
                    {
                        PreencheUsuarioModel(resultado);

                        App.Current.MainPage = new Menu();

                        await App.SQLiteDbUsuario.SaveItemAsync(this._usuario);
                    }
                    else
                    {
                        await DisplayAlert("ERRO!", "Login ou senha incorretos.", "OK");
                        return;
                    }

                }
                else
                {
                    //await AtualizaUsuariosBD();
                    await Task.Delay(5000);
                    if (usuario != null)    
                    {
                        DataTable resultado = Conexao.SelectLogin(EntryUsuario.Text, EntrySenha.Text);
                        if (resultado != null && resultado.Rows.Count > 0)
                        {
                            PreencheUsuarioModel(resultado);
                            App.Current.MainPage = new Menu();
                        }
                        else
                        {
                            await DisplayAlert("ERRO!", "Login ou senha incorretos.", "OK");
                        }

                    }
                    else
                    {
                        await DisplayAlert("ERRO!", "Login ou senha incorretos.", "OK");

                    }
                    
                }
            }
            catch (Exception ex)
            {
                // Tratamento de exceção, caso ocorra algum erro
                Console.WriteLine("Ocorreu um erro: " + ex.Message);
            }
        }

        public void PreencheUsuarioModel(DataTable resultado)
        {
            IdUsr.ValorIdUsr = Convert.ToInt32(resultado.Rows[0]["id"]);
        }

        public async Task AtualizaUsuariosBD()
        {
            try
            {
                var current = Connectivity.NetworkAccess;

                if (current == NetworkAccess.Internet)
                {
                    DataTable dt = DAL.SelectUsuarios();

                    if (dt.Rows.Count > 0)
                    {
                        App.SQLiteDbUsuario.DeleteAllUsers();
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            Models.Usuario usuario = new Models.Usuario()
                            {
                                Nome = dt.Rows[i][1].ToString(),
                                Senha = dt.Rows[i][2].ToString()
                            };
                            App.SQLiteDbUsuario.SaveItemAsync(usuario);
                        }
                    }
                }
            }
            catch (Exception ex)
            {

                //await DisplayAlert("Atenção", "Falha ao se conectar com o banco de dados\nVerifique sua conexão com a internet", "OK");
            }
        }


    }
}
